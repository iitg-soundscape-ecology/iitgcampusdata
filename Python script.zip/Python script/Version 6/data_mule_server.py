import sys
import os
import time
import json
import socket
import shutil
import threading
import subprocess
import datetime
from flask import Flask, request, jsonify, send_from_directory, render_template_string

# -----------------------------------------------------------------------------
# D-BUS BLE DEPENDENCIES WITH PLATFORM FALLBACK
# -----------------------------------------------------------------------------
DBUS_SUPPORTED = False
try:
    import dbus
    import dbus.service
    import dbus.mainloop.glib
    from gi.repository import GLib
    DBUS_SUPPORTED = True
except ImportError:
    pass

# -----------------------------------------------------------------------------
# CONSTANTS & BLUEZ DBUS INTERFACES
# -----------------------------------------------------------------------------
BLUEZ_SERVICE_NAME = 'org.bluez'
DBUS_OM_IFACE = 'org.freedesktop.DBus.ObjectManager'
DBUS_PROP_IFACE = 'org.freedesktop.DBus.Properties'
GATT_MANAGER_IFACE = 'org.bluez.GattManager1'
GATT_SERVICE_IFACE = 'org.bluez.GattService1'
GATT_CHRC_IFACE = 'org.bluez.GattCharacteristic1'
LE_ADVERTISING_MANAGER_IFACE = 'org.bluez.LEAdvertisingManager1'
LE_ADVERTISEMENT_IFACE = 'org.bluez.LEAdvertisement1'

# Target Wi-Fi SSID for data mule connection (easily configurable for debugging)
TARGET_SSID = "Bibek"

# -----------------------------------------------------------------------------
# D-BUS BLE CLASSES (Only defined if D-Bus is supported)
# -----------------------------------------------------------------------------
if DBUS_SUPPORTED:
    class Advertisement(dbus.service.Object):
        PATH_BASE = '/org/bluez/example/advertisement'

        def __init__(self, bus, index, uuid):
            self.path = self.PATH_BASE + str(index)
            self.bus = bus
            self.uuid = uuid
            dbus.service.Object.__init__(self, bus, self.path)

        def get_properties(self):
            properties = dict()
            properties['Type'] = 'peripheral'
            properties['ServiceUUIDs'] = dbus.Array([self.uuid], signature='s')
            properties['LocalName'] = dbus.String('Forest_Ear_BLE')
            properties['Discoverable'] = dbus.Boolean(True)
            return {LE_ADVERTISEMENT_IFACE: properties}

        @dbus.service.method(DBUS_PROP_IFACE, in_signature='ss', out_signature='v')
        def Get(self, interface, prop):
            if interface != LE_ADVERTISEMENT_IFACE:
                raise dbus.exceptions.DBusException('org.freedesktop.DBus.Error.InvalidArgs')
            properties = self.get_properties()[LE_ADVERTISEMENT_IFACE]
            return properties.get(prop)

        @dbus.service.method(DBUS_PROP_IFACE, in_signature='s', out_signature='a{sv}')
        def GetAll(self, interface):
            if interface != LE_ADVERTISEMENT_IFACE:
                raise dbus.exceptions.DBusException('org.freedesktop.DBus.Error.InvalidArgs')
            return self.get_properties()[LE_ADVERTISEMENT_IFACE]

        @dbus.service.method(LE_ADVERTISEMENT_IFACE, in_signature='', out_signature='')
        def Release(self):
            print('%s: Released' % self.path)

    class Application(dbus.service.Object):
        def __init__(self, bus):
            self.path = '/'
            self.services = []
            dbus.service.Object.__init__(self, bus, self.path)

        def add_service(self, service):
            self.services.append(service)

        def get_path(self):
            return dbus.ObjectPath(self.path)

        @dbus.service.method(DBUS_OM_IFACE, in_signature='', out_signature='a{oa{sa{sv}}}')
        def GetManagedObjects(self):
            response = {}
            for service in self.services:
                response[service.get_path()] = service.get_properties()
                chrcs = service.get_characteristics()
                for chrc in chrcs:
                    response[chrc.get_path()] = chrc.get_properties()
            return response

    class Service(dbus.service.Object):
        PATH_BASE = '/org/bluez/example/service'

        def __init__(self, bus, index, uuid, primary):
            self.path = self.PATH_BASE + str(index)
            self.bus = bus
            self.uuid = uuid
            self.primary = primary
            self.characteristics = []
            dbus.service.Object.__init__(self, bus, self.path)

        def get_properties(self):
            return {
                GATT_SERVICE_IFACE: {
                    'UUID': dbus.String(self.uuid),
                    'Primary': dbus.Boolean(self.primary),
                    'Characteristics': dbus.Array(
                        [c.get_path() for c in self.characteristics],
                        signature='o'
                    )
                }
            }

        def get_path(self):
            return dbus.ObjectPath(self.path)

        def add_characteristic(self, characteristic):
            self.characteristics.append(characteristic)

        def get_characteristics(self):
            return self.characteristics

        @dbus.service.method(DBUS_PROP_IFACE, in_signature='ss', out_signature='v')
        def Get(self, interface, prop):
            if interface != GATT_SERVICE_IFACE:
                raise dbus.exceptions.DBusException('org.freedesktop.DBus.Error.InvalidArgs')
            properties = self.get_properties()[GATT_SERVICE_IFACE]
            return properties.get(prop)

        @dbus.service.method(DBUS_PROP_IFACE, in_signature='s', out_signature='a{sv}')
        def GetAll(self, interface):
            if interface != GATT_SERVICE_IFACE:
                raise dbus.exceptions.DBusException('org.freedesktop.DBus.Error.InvalidArgs')
            return self.get_properties()[GATT_SERVICE_IFACE]

    class Characteristic(dbus.service.Object):
        def __init__(self, bus, index, uuid, flags, service):
            self.path = service.path + '/char' + str(index)
            self.bus = bus
            self.uuid = uuid
            self.flags = flags
            self.service = service
            self.value = []
            self.notifying = False
            dbus.service.Object.__init__(self, bus, self.path)

        def get_properties(self):
            return {
                GATT_CHRC_IFACE: {
                    'Service': dbus.ObjectPath(self.service.get_path()),
                    'UUID': dbus.String(self.uuid),
                    'Flags': dbus.Array(self.flags, signature='s'),
                    'Notifying': dbus.Boolean(self.notifying)
                }
            }

        def get_path(self):
            return dbus.ObjectPath(self.path)

        @dbus.service.method(DBUS_PROP_IFACE, in_signature='ss', out_signature='v')
        def Get(self, interface, prop):
            if interface != GATT_CHRC_IFACE:
                raise dbus.exceptions.DBusException('org.freedesktop.DBus.Error.InvalidArgs')
            properties = self.get_properties()[GATT_CHRC_IFACE]
            return properties.get(prop)

        @dbus.service.method(DBUS_PROP_IFACE, in_signature='s', out_signature='a{sv}')
        def GetAll(self, interface):
            if interface != GATT_CHRC_IFACE:
                raise dbus.exceptions.DBusException('org.freedesktop.DBus.Error.InvalidArgs')
            return self.get_properties()[GATT_CHRC_IFACE]

        @dbus.service.method(GATT_CHRC_IFACE, in_signature='a{sv}', out_signature='ay')
        def ReadValue(self, options):
            return self.read_value(options)

        @dbus.service.method(GATT_CHRC_IFACE, in_signature='aya{sv}', out_signature='')
        def WriteValue(self, value, options):
            self.write_value(value, options)

        @dbus.service.method(GATT_CHRC_IFACE, in_signature='', out_signature='')
        def StartNotify(self):
            self.start_notify()

        @dbus.service.method(GATT_CHRC_IFACE, in_signature='', out_signature='')
        def StopNotify(self):
            self.stop_notify()

        def read_value(self, options):
            return dbus.Array(self.value, signature='y')

        def write_value(self, value, options):
            pass

        def start_notify(self):
            self.notifying = True

        def stop_notify(self):
            self.notifying = False

        @dbus.service.signal(DBUS_PROP_IFACE, signature='sa{sv}as')
        def PropertiesChanged(self, interface, changed_properties, invalidated_properties):
            pass

    class MuleControlCharacteristic(Characteristic):
        def __init__(self, bus, index, uuid, service, server_state):
            Characteristic.__init__(self, bus, index, uuid, ['read', 'write', 'notify'], service)
            self.server_state = server_state
            self.server_state.ble_characteristic = self
            self.update_value("Send 'WAKE' to start Wi-Fi, 'SLEEP' to stop Wi-Fi")

        def update_value(self, new_val):
            if not new_val.endswith('\n'):
                new_val += '\n'
            self.value = [dbus.Byte(b) for b in new_val.encode('utf-8')]
            if self.notifying:
                # Emit PropertiesChanged D-Bus signal to notify clients
                self.PropertiesChanged(GATT_CHRC_IFACE, {'Value': dbus.Array(self.value, signature='y')}, [])

        def read_value(self, options):
            val_str = "".join([chr(int(b)) for b in self.value])
            print(f"[BLE] Read request received, returning: {val_str}")
            return dbus.Array(self.value, signature='y')

        def write_value(self, value, options):
            try:
                command = "".join([chr(int(b)) for b in value]).strip()
                print(f"[BLE] Write request received: {command}")
                cmd_lower = command.lower()
                if cmd_lower in ["wake", "start", "wifi_on", "on"]:
                    self.update_value("Waking up Wi-Fi...")
                    # Wake up Wi-Fi in a background thread to return instantly
                    threading.Thread(target=self.server_state.wake_wifi, args=(self,), daemon=True).start()
                elif cmd_lower in ["sleep", "off", "wifi_off", "sleep_wifi", "stop", "shutdown"]:
                    self.update_value("Putting Wi-Fi to sleep...")
                    # Sleep Wi-Fi in a background thread to return instantly
                    threading.Thread(target=self.server_state.sleep_wifi, daemon=True).start()
                elif cmd_lower in ["status", "record", "recording", "rec"]:
                    status_msg = self.server_state.get_recording_status_summary()
                    self.update_value(status_msg)
                else:
                    self.update_value(f"Unknown cmd: '{command}'. Available: WAKE, SLEEP, STATUS")
            except Exception as e:
                print("[BLE] Error processing write:", e)

# -----------------------------------------------------------------------------
# D-BUS UTILITY FUNCTIONS
# -----------------------------------------------------------------------------
def find_adapter(bus):
    remote_om = dbus.Interface(bus.get_object(BLUEZ_SERVICE_NAME, '/'), DBUS_OM_IFACE)
    objects = remote_om.GetManagedObjects()
    for path, interfaces in objects.items():
        if LE_ADVERTISING_MANAGER_IFACE in interfaces and GATT_MANAGER_IFACE in interfaces:
            return path
    return None

def register_ble_app(bus, adapter_path, app):
    service_provider = dbus.Interface(bus.get_object(BLUEZ_SERVICE_NAME, adapter_path), GATT_MANAGER_IFACE)
    service_provider.RegisterApplication(app.get_path(), {},
        reply_handler=lambda: print('[BLE] GATT application registered successfully'),
        error_handler=lambda err: print('[BLE] Failed to register GATT application: ' + str(err)))

def register_ble_ad(bus, adapter_path, ad):
    ad_provider = dbus.Interface(bus.get_object(BLUEZ_SERVICE_NAME, adapter_path), LE_ADVERTISING_MANAGER_IFACE)
    ad_provider.RegisterAdvertisement(ad.path, {},
        reply_handler=lambda: print('[BLE] Advertisement registered successfully'),
        error_handler=lambda err: print('[BLE] Failed to register advertisement: ' + str(err)))

# -----------------------------------------------------------------------------
# DATA MULE SYSTEM STATE
# -----------------------------------------------------------------------------
class DataMuleServerState:
    def __init__(self):
        # Paths configured matching soundscape_ngrok_final.py
        self.config_path = "/home/rpi/Desktop/Working code/data_mule_config.json"   
        self.is_wifi_active = False
        self.flask_started = False
        self.last_sms_time = time.time()
        self.target_ssid = TARGET_SSID
        self.load_config()
        
    @property
    def output_dir(self):
        primary_dir = "/media/rpi/ForestEar/Audio_Recordings"
        fallback_dir = "/home/rpi/Desktop/Working code/audio_recordings_temp"
        
        if os.path.exists(primary_dir):
            target_dir = primary_dir
        else:
            target_dir = fallback_dir
        os.makedirs(target_dir, exist_ok=True)
        return target_dir
        
    def load_config(self):
        os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
        os.makedirs(self.output_dir, exist_ok=True)
        
        defaults = {
            "duration": 10,
            "pause": 20,
            "phone": "+919876543210",
            "sms_val": 1,
            "sms_unit": "hr",
            "modem_port": "/dev/ttyUSB2",
            "target_ssid": self.target_ssid
        }
        
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, "r") as f:
                    self.config = json.load(f)
                    for k, v in defaults.items():
                        if k not in self.config:
                            self.config[k] = v
            except Exception as e:
                print("[ERROR] Failed to load config, using defaults:", e)
                self.config = defaults
        else:
            self.config = defaults
            self.save_config(self.config)
        
        self.target_ssid = self.config.get("target_ssid", TARGET_SSID)

    def save_config(self, new_config):
        self.config = new_config
        try:
            with open(self.config_path, "w") as f:
                json.dump(self.config, f, indent=2)
            print("[INFO] Config saved:", self.config)
        except Exception as e:
            print("[ERROR] Failed to save config:", e)

    def get_battery_percentage(self):
        # Check standard Linux power supply configurations if present
        try:
            for ps_path in ["/sys/class/power_supply/BAT0", "/sys/class/power_supply/battery"]:
                if os.path.exists(ps_path):
                    with open(os.path.join(ps_path, "capacity"), "r") as f:
                        return int(f.read().strip())
        except Exception:
            pass
        return 92  # Premium mock battery default

    def get_sd_percentage(self):
        try:
            total, used, free = shutil.disk_usage(self.output_dir)
            return (used / total) * 100.0
        except Exception as e:
            print("[ERROR] Failed to read disk usage:", e)
            return 0.0

    def send_sms(self, message):
        port = self.config.get("modem_port", "/dev/ttyUSB2")
        phone = self.config.get("phone", "+919876543210")
        if not port or port.lower() == "none":
            print(f"[SMS MOCK] To {phone}: {message}")
            return True
            
        try:
            print(f"[SMS] Transmitting to {phone} via modem at {port}...")
            import serial
            ser = serial.Serial(port, baudrate=115200, timeout=5)
            ser.write(b"AT+CMGF=1\r")
            time.sleep(1)
            ser.read_all() # Clear buffer
            
            cmd = f'AT+CMGS="{phone}"\r'
            ser.write(cmd.encode())
            time.sleep(1)
            
            ser.write(f"{message}\r\n".encode())
            time.sleep(1)
            ser.write(bytes([26])) # Ctrl+Z
            time.sleep(3)
            
            response = ser.read_all().decode(errors="ignore")
            print("[SMS] Modem response:", response)
            ser.close()
            return "OK" in response or "+CMGS:" in response
        except Exception as e:
            print("[SMS ERROR] Failed to send SMS:", e)
            return False

    def wake_wifi(self, characteristic=None):
        if self.is_wifi_active:
            if characteristic:
                ip = self.get_ip_address()
                characteristic.update_value(f"IP: http://{ip}")
            return
            
        print("[WAKE] Enabling Wi-Fi adapter...")
        try:
            # rfkill unblocks hardware RF switches
            subprocess.run(["sudo", "rfkill", "unblock", "wifi"], check=False)
            subprocess.run(["sudo", "ip", "link", "set", "wlan0", "up"], check=False)
            # Ensure NetworkManager radio is on if present
            subprocess.run(["sudo", "nmcli", "radio", "wifi", "on"], capture_output=True, timeout=5)
        except Exception as e:
            print("[WAKE] Error executing system WiFi enable:", e)
            
        # Allow interface initialization
        time.sleep(2)
        
        # Trigger connection to available Wi-Fi networks
        print("[WAKE] Scanning and connecting to available Wi-Fi networks...")
        connected = False
        
        # Step 1: NetworkManager connection logic
        try:
            # Rescan Wi-Fi networks nearby
            subprocess.run(["sudo", "nmcli", "device", "wifi", "rescan"], capture_output=True, timeout=10)
            time.sleep(2)
            
            # If target_ssid is specified and configured, try it first
            if hasattr(self, 'target_ssid') and self.target_ssid and self.target_ssid.strip():
                print(f"[WAKE] Attempting connection to target SSID '{self.target_ssid}'...")
                nmcli_res = subprocess.run(["sudo", "nmcli", "connection", "up", self.target_ssid], capture_output=True, text=True, timeout=15)
                if nmcli_res.returncode == 0:
                    print(f"[WAKE] Connected to SSID '{self.target_ssid}' via NetworkManager.")
                    connected = True

            # If not connected yet, tell NetworkManager to connect wlan0 to any available known network
            if not connected:
                print("[WAKE] Auto-connecting to any available Wi-Fi network via NetworkManager...")
                nmcli_dev_res = subprocess.run(["sudo", "nmcli", "device", "connect", "wlan0"], capture_output=True, text=True, timeout=15)
                if nmcli_dev_res.returncode == 0:
                    print("[WAKE] Connected to available Wi-Fi via NetworkManager device connect.")
                    connected = True
                else:
                    print(f"[WAKE] nmcli device connect log: {nmcli_dev_res.stdout.strip()}")
        except Exception as e:
            print(f"[WAKE] NetworkManager connect error: {e}")

        # Step 2: wpa_cli fallback if NetworkManager did not connect
        if not connected:
            print("[WAKE] Trying wpa_cli fallback to connect to available networks...")
            try:
                wpa_res = subprocess.run(["sudo", "wpa_cli", "-i", "wlan0", "list_networks"], capture_output=True, text=True, timeout=5)
                if wpa_res.returncode == 0:
                    # Enable all configured networks in wpa_supplicant
                    for line in wpa_res.stdout.splitlines()[1:]:
                        parts = line.split()
                        if parts and parts[0].isdigit():
                            net_id = parts[0]
                            subprocess.run(["sudo", "wpa_cli", "-i", "wlan0", "enable_network", net_id], capture_output=True, timeout=3)
                    subprocess.run(["sudo", "wpa_cli", "-i", "wlan0", "reconnect"], capture_output=True, timeout=5)
                    print("[WAKE] Enabled all networks and reassociated via wpa_cli.")
            except Exception as e:
                print(f"[WAKE] wpa_cli fallback error: {e}")
            
        # Poll for IP assignment
        ip = None
        for i in range(15):
            time.sleep(1)
            ip = self.get_ip_address()
            if ip and ip != "127.0.0.1":
                break
                
        if not ip or ip == "127.0.0.1":
            ip_val = "Wi-Fi wake timed out. Check networks."
        else:
            self.is_wifi_active = True
            ip_val = f"IP: http://{ip}"
            print(f"[WAKE] Wi-Fi Active. URL: {ip_val}")
            
        # Start Flask web server in a background thread if not already running
        if not self.flask_started:
            print("[WAKE] Starting Flask Web Server...")
            def run_flask():
                try:
                    app.run(host="0.0.0.0", port=80, debug=False, use_reloader=False)
                except Exception as e:
                    print("[ERROR] Web server failed to bind to port 80 (likely requires sudo / root privileges):", e)
                    print("[INFO] Attempting fallback to port 8080...")
                    app.run(host="0.0.0.0", port=8080, debug=False, use_reloader=False)
            
            threading.Thread(target=run_flask, daemon=True).start()
            self.flask_started = True
            
        if characteristic:
            characteristic.update_value(ip_val)

    def sleep_wifi(self):
        print("[SLEEP] Disabling Wi-Fi adapter...")
        
        # Send notification feedback to the BLE terminal
        if hasattr(self, "ble_characteristic") and self.ble_characteristic:
            try:
                self.ble_characteristic.update_value("Wi-Fi has been turned off / Server is sleeping.")
                print("[SLEEP] Updated BLE characteristic notification.")
            except Exception as e:
                print("[SLEEP] Failed to update BLE characteristic:", e)
                
        try:
            subprocess.run(["sudo", "nmcli", "radio", "wifi", "off"], capture_output=True, timeout=5)
            subprocess.run(["sudo", "rfkill", "block", "wifi"], check=False)
            subprocess.run(["sudo", "ip", "link", "set", "wlan0", "down"], check=False)
            self.is_wifi_active = False
            print("[SLEEP] Wi-Fi adapter disabled successfully.")
        except Exception as e:
            print("[SLEEP] Error executing system WiFi block:", e)

    def get_ip_address(self):
        try:
            ips = subprocess.check_output(["hostname", "-I"]).decode().strip().split()
            for ip in ips:
                if not ip.startswith("127."):
                    return ip
        except Exception:
            pass
        return None

    def get_recording_status_summary(self):
        # 1. Check if the recorder service is active
        service_status = "inactive"
        try:
            res = subprocess.run(["systemctl", "is-active", "soundscape_recorder.service"], 
                                 capture_output=True, text=True, timeout=2)
            service_status = res.stdout.strip()
        except Exception as e:
            service_status = f"error ({e})"

        # 2. Check if currently recording (is 'sox' process running?)
        is_recording = "Idle"
        try:
            res = subprocess.run(["pgrep", "sox"], capture_output=True, text=True)
            if res.returncode == 0:
                is_recording = "Recording"
        except Exception:
            pass

        # 3. Read total files and last recording from CSV log or directory
        total_files = 0
        try:
            if os.path.exists(self.output_dir):
                total_files = len([f for f in os.listdir(self.output_dir) if f.endswith(".wav")])
        except Exception:
            pass

        last_log = "No log found"
        csv_path = os.path.join(self.output_dir, "sound_log.csv")
        if os.path.exists(csv_path):
            try:
                with open(csv_path, "r") as f:
                    lines = f.readlines()
                    if len(lines) > 1:
                        # Grab the last line (most recent log)
                        last_line = lines[-1].strip()
                        parts = last_line.split(",")
                        if len(parts) >= 4:
                            ts, audio_file, cls, conf = parts[0], parts[1], parts[2], parts[3]
                            last_log = f"{audio_file} -> {cls} ({conf}) at {ts}"
                        else:
                            last_log = last_line
            except Exception as e:
                last_log = f"Err: {e}"

        return (
            f"[REC STATUS]\n"
            f"Service: {service_status} ({is_recording})\n"
            f"Total WAVs: {total_files}\n"
            f"Last: {last_log}\n"
        )

# Initialize server state global
server_state = DataMuleServerState()

# -----------------------------------------------------------------------------
# FLASK WEB APPLICATION SETUP
# -----------------------------------------------------------------------------
app = Flask(__name__)

# Premium professional UI Dashboard template (No emojis, sleek dark-themed design)
DASHBOARD_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Rainforest Data Mule</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Inter:ital,opsz,wght@0,14..32,300..700;1,14..32,300..700&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --background: 240 6% 7%;
            --foreground: 240 5% 96%;
            --card: 240 6% 10%;
            --card-foreground: 240 5% 96%;
            --primary: 255 60% 58%;
            --primary-hover: 255 60% 65%;
            --muted: 240 5% 16%;
            --muted-foreground: 240 4% 55%;
            --border: 240 5% 18%;
            --radius: 1rem;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        body {
            background-color: hsl(var(--background));
            color: hsl(var(--foreground));
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            overflow-x: clip;
        }

        header {
            position: sticky;
            top: 0;
            z-index: 50;
            width: 100%;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            background-color: hsla(var(--background), 0.8);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
        }

        .header-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 1.5rem;
            height: 4rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 0.65rem;
        }

        .logo svg {
            color: hsl(var(--primary));
            width: 24px;
            height: 24px;
            flex-shrink: 0;
        }

        .logo-title {
            display: flex;
            flex-direction: column;
            line-height: 1.05;
        }

        .logo-title .italic {
            font-family: 'Instrument Serif', Georgia, serif;
            font-style: italic;
            font-size: 1.45rem;
            font-weight: 400;
            letter-spacing: -0.01em;
            color: hsl(var(--foreground));
        }

        .logo-title .sub {
            font-size: 0.75rem;
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            font-weight: 500;
            color: hsl(var(--muted-foreground));
            letter-spacing: 0.05em;
            text-transform: uppercase;
        }

        .header-actions-wrapper {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .header-actions-wrapper .mobile-tab-btn {
            display: none;
        }

        .badge-status {
            display: flex;
            align-items: center;
            gap: 0.35rem;
            font-size: 0.75rem;
            font-family: 'JetBrains Mono', monospace;
            background-color: hsl(var(--muted));
            border: 1px solid rgba(255, 255, 255, 0.05);
            padding: 0.25rem 0.65rem;
            border-radius: 9999px;
            color: hsl(var(--muted-foreground));
        }

        /* Grid Layout */
        .main-layout {
            max-width: 1400px;
            width: 100%;
            margin: 0 auto;
            padding: 1.5rem;
            display: grid;
            grid-template-columns: 4fr 8fr;
            gap: 1.5rem;
            flex: 1;
        }

        /* Card layout */
        .card {
            background-color: hsl(var(--card));
            border: 1px solid rgba(255, 255, 255, 0.05);
            border-radius: var(--radius);
            padding: 1.5rem;
            display: flex;
            flex-direction: column;
            gap: 1.25rem;
            height: fit-content;
        }

        .card-title {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-family: 'Instrument Serif', Georgia, serif;
            font-size: 1.35rem;
            font-style: italic;
            color: hsl(var(--foreground));
        }

        .card-title svg {
            color: hsl(var(--primary));
        }

        .card-subtitle {
            font-size: 0.75rem;
            color: hsl(var(--muted-foreground));
            margin-top: -0.85rem;
            font-family: 'Inter', sans-serif;
        }

        /* Form Styling */
        .form-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 1rem;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 0.35rem;
        }

        .form-group label {
            font-size: 0.7rem;
            font-weight: 600;
            color: hsl(var(--muted-foreground));
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .form-group input, .form-group select {
            background-color: hsl(var(--background));
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 0.5rem;
            padding: 0.65rem 0.85rem;
            color: hsl(var(--foreground));
            font-family: 'Inter', sans-serif;
            font-size: 0.875rem;
            transition: border-color 0.2s ease, box-shadow 0.2s ease;
        }

        .form-group input:focus, .form-group select:focus {
            outline: none;
            border-color: hsl(var(--primary));
            box-shadow: 0 0 0 2px hsla(var(--primary), 0.2);
        }

        .sms-input-group {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 0.5rem;
        }

        /* Buttons */
        .btn-group {
            display: flex;
            flex-direction: column;
            gap: 0.75rem;
            margin-top: 0.5rem;
        }

        .btn-tactile {
            background: linear-gradient(180deg, hsl(var(--card)) 0%, hsl(var(--background)) 100%);
            box-shadow:
                inset 0 1px 0 0 rgba(255, 255, 255, 0.05),
                0 1px 3px 0 rgba(0, 0, 0, 0.2),
                0 1px 2px -1px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 9999px;
            padding: 0.65rem 1.25rem;
            color: hsl(var(--foreground));
            font-family: 'Inter', sans-serif;
            font-size: 0.85rem;
            font-weight: 500;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            transition: all 0.15s ease;
            text-decoration: none;
        }

        .btn-tactile:hover {
            box-shadow:
                inset 0 1px 0 0 rgba(255, 255, 255, 0.08),
                0 2px 8px 0 rgba(0, 0, 0, 0.25),
                0 1px 2px -1px rgba(0, 0, 0, 0.15);
            transform: translateY(-1px);
        }

        .btn-tactile:active {
            transform: translateY(0) scale(0.98);
            box-shadow: inset 0 2px 4px 0 rgba(0, 0, 0, 0.3);
        }

        .btn-tactile:disabled {
            opacity: 0.5;
            cursor: not-allowed;
            transform: none !important;
            box-shadow: none !important;
        }

        .btn-tactile.primary {
            background: hsl(var(--primary));
            color: #fff;
            border-color: hsla(var(--primary), 0.2);
        }

        .btn-tactile.primary:hover {
            background: hsl(var(--primary-hover));
        }

        .btn-tactile.warning {
            background: linear-gradient(180deg, #d97706 0%, #b45309 100%);
            border-color: rgba(217, 119, 6, 0.2);
            color: #fff;
        }

        .btn-tactile.warning:hover {
            background: #f59e0b;
        }

        .btn-tactile.danger {
            background: linear-gradient(180deg, #dc2626 0%, #991b1b 100%);
            color: #fff;
            border-color: rgba(220, 38, 38, 0.2);
        }

        .btn-tactile.danger:hover {
            background: #ef4444;
        }

        /* File panel section */
        .files-control-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 1rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            padding-bottom: 1rem;
        }

        .search-container {
            position: relative;
            flex: 1;
            min-width: 240px;
        }

        .search-container input {
            width: 100%;
            background-color: hsl(var(--background));
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 9999px;
            padding: 0.55rem 1rem 0.55rem 2.25rem;
            color: hsl(var(--foreground));
            font-family: 'Inter', sans-serif;
            font-size: 0.85rem;
            transition: border-color 0.2s ease;
        }

        .search-container input:focus {
            outline: none;
            border-color: hsl(var(--primary));
        }

        .search-icon {
            position: absolute;
            left: 0.75rem;
            top: 50%;
            transform: translateY(-50%);
            color: hsl(var(--muted-foreground));
            pointer-events: none;
        }

        .bulk-actions-group {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            flex-wrap: wrap;
        }

        /* Custom Checkbox */
        .checkbox-container {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            cursor: pointer;
            font-size: 0.8rem;
            color: hsl(var(--muted-foreground));
            user-select: none;
        }

        .checkbox-container input {
            display: none;
        }

        .custom-checkbox {
            width: 1.1rem;
            height: 1.1rem;
            border: 1px solid rgba(255, 255, 255, 0.15);
            border-radius: 0.25rem;
            background-color: hsl(var(--background));
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s ease;
        }

        .checkbox-container input:checked + .custom-checkbox {
            background-color: hsl(var(--primary));
            border-color: hsl(var(--primary));
        }

        .checkbox-container input:checked + .custom-checkbox::after {
            content: '';
            width: 4px;
            height: 8px;
            border: solid white;
            border-width: 0 2px 2px 0;
            transform: rotate(45deg);
            margin-bottom: 2px;
        }

        /* Table styling */
        .table-wrapper {
            overflow-x: auto;
            margin-top: 0.5rem;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.875rem;
        }

        th {
            text-align: left;
            padding: 0.75rem 1.0rem;
            color: hsl(var(--muted-foreground));
            font-weight: 500;
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }

        td {
            padding: 0.75rem 1.0rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.03);
            vertical-align: middle;
        }

        .file-row {
            transition: background-color 0.15s ease, opacity 0.2s ease;
        }

        .file-row:hover {
            background-color: rgba(255, 255, 255, 0.015);
        }

        .file-row.dimmed {
            opacity: 0.6;
        }

        .filename {
            font-family: 'JetBrains Mono', monospace;
            font-weight: 500;
            color: hsl(var(--foreground));
            word-break: break-all;
        }

        .badge {
            display: inline-block;
            padding: 0.2rem 0.5rem;
            border-radius: 0.25rem;
            font-size: 0.65rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.03em;
        }

        .badge-new {
            background-color: hsla(var(--primary), 0.1);
            color: hsl(var(--primary));
            border: 1px solid hsla(var(--primary), 0.2);
        }

        .badge-downloaded {
            background-color: rgba(255, 255, 255, 0.05);
            color: hsl(var(--muted-foreground));
            border: 1px solid rgba(255, 255, 255, 0.05);
        }

        .actions-cell {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-icon {
            width: 2.2rem;
            height: 2.2rem;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 9999px;
            background-color: hsl(var(--background));
            border: 1px solid rgba(255, 255, 255, 0.05);
            color: hsl(var(--muted-foreground));
            cursor: pointer;
            transition: all 0.2s ease;
            text-decoration: none;
        }

        .btn-icon:hover {
            color: hsl(var(--foreground));
            background-color: hsl(var(--muted));
            border-color: rgba(255, 255, 255, 0.1);
        }

        .btn-icon.primary:hover {
            color: #fff;
            background-color: hsl(var(--primary));
            border-color: hsl(var(--primary));
        }

        .btn-icon.danger:hover {
            color: #fff;
            background-color: #ef4444;
            border-color: #ef4444;
        }

        /* Toast and Modals */
        #toast {
            position: fixed;
            bottom: 1.5rem;
            right: 1.5rem;
            background-color: hsl(var(--card));
            border: 1px solid hsl(var(--primary));
            color: hsl(var(--foreground));
            padding: 0.75rem 1.25rem;
            border-radius: 9999px;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            box-shadow: 0 10px 30px rgba(0,0,0,0.5);
            font-size: 0.85rem;
            font-weight: 500;
            transform: translateY(100px);
            opacity: 0;
            transition: transform 0.3s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.3s;
            z-index: 1000;
        }

        #toast.show {
            transform: translateY(0);
            opacity: 1;
        }

        .modal {
            position: fixed;
            inset: 0;
            background-color: rgba(0,0,0,0.85);
            backdrop-filter: blur(5px);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.3s ease;
            z-index: 999;
        }

        .modal.show {
            opacity: 1;
            pointer-events: auto;
        }

        .modal-content {
            background-color: hsl(var(--card));
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: var(--radius);
            padding: 2rem;
            width: 90%;
            max-width: 450px;
            text-align: center;
            box-shadow: 0 20px 50px rgba(0,0,0,0.6);
        }

        .modal-title {
            font-family: 'Instrument Serif', Georgia, serif;
            font-size: 1.5rem;
            font-style: italic;
            margin-bottom: 0.5rem;
        }

        .progress-container {
            width: 100%;
            background-color: hsl(var(--background));
            height: 6px;
            border-radius: 999px;
            overflow: hidden;
            margin: 1.5rem 0 0.75rem;
            border: 1px solid rgba(255, 255, 255, 0.03);
        }

        .progress-bar {
            height: 100%;
            background-color: hsl(var(--primary));
            width: 0%;
            transition: width 0.15s ease;
        }

        .progress-text {
            font-size: 0.8rem;
            color: hsl(var(--muted-foreground));
            font-family: 'JetBrains Mono', monospace;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 3rem 1rem;
            color: hsl(var(--muted-foreground));
        }

        .empty-state svg {
            color: hsla(var(--primary), 0.2);
            margin-bottom: 1rem;
            display: block;
            margin-left: auto;
            margin-right: auto;
        }

        /* Responsive Grid System matching Whisper design */
        @media (max-width: 1024px) {
            .main-layout {
                grid-template-columns: 1fr;
                padding: 1rem;
            }
            
            .logo {
                display: flex;
                margin-bottom: 0.25rem;
            }
            
            .header-container {
                height: auto;
                padding: 0.75rem 1rem;
                width: 100%;
                display: flex;
                flex-direction: column;
                align-items: flex-start;
                gap: 0.75rem;
            }
            
            .header-actions-wrapper {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 0.5rem 0.75rem;
                width: 100%;
            }
            
            .header-actions-wrapper .mobile-tab-btn {
                display: flex;
                align-items: center;
                justify-content: center;
                background-color: rgba(255, 255, 255, 0.03);
                border: 1px solid rgba(255, 255, 255, 0.05);
                color: hsl(var(--muted-foreground));
                padding: 0.5rem 1rem;
                border-radius: 9999px;
                font-family: 'JetBrains Mono', monospace;
                font-size: 0.75rem;
                font-weight: 500;
                text-transform: uppercase;
                letter-spacing: 0.05em;
                cursor: pointer;
                transition: all 0.2s ease;
                outline: none;
                width: 100%;
            }
            
            .header-actions-wrapper .mobile-tab-btn.active {
                background-color: hsl(var(--foreground));
                color: hsl(var(--background));
                border-color: hsl(var(--foreground));
                font-weight: 600;
            }
            
            .badge-status {
                width: 100%;
                justify-content: center;
                height: 100%;
                padding: 0.5rem 1rem;
            }
            
            .tab-content {
                display: none;
            }
            
            .tab-content.active {
                display: flex !important;
            }
        }

        @media (min-width: 1025px) {
            .tab-content {
                display: flex !important;
            }
        }

        @media (max-width: 640px) {
            .header-container {
                padding: 0 1rem;
            }
            .logo h1 {
                font-size: 1.25rem;
            }
            .header-container {
                padding: 0.75rem 1rem;
            }
            
            /* Hide columns on small screens for optimal fit */
            th:nth-child(3), td:nth-child(3) { /* Size */
                display: none;
            }
            th:nth-child(4), td:nth-child(4) { /* Status */
                display: none;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <div class="logo">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 3.58 1 8a7 7 0 0 1-9 10Z"/><path d="M9 22v-4h4"/></svg>
                <div class="logo-title">
                    <span class="italic">Forest Ear</span>
                    <span class="sub">Data Mule</span>
                </div>
            </div>
            <div class="header-actions-wrapper">
                <div class="badge-status" data-val="{{ sd_pct }}% SD" title="SD Disk Usage">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><line x1="9" x2="9" y1="3" y2="9"/><line x1="15" x2="15" y1="3" y2="9"/><line x1="3" x2="9" y1="9" y2="9"/><line x1="15" x2="21" y1="9" y2="9"/></svg>
                    <span>Disk: {{ sd_pct }}%</span>
                </div>
                <button id="hubBtn" class="mobile-tab-btn active" onclick="switchTab('hub')">Control Hub</button>
                <div class="badge-status" data-val="{{ bat_pct }}% Bat" title="Mule Battery Level">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="16" height="10" rx="2" ry="2"/><line x1="22" y1="11" x2="22" y2="13"/></svg>
                    <span>Battery: {{ bat_pct }}%</span>
                </div>
                <button id="recordingsBtn" class="mobile-tab-btn" onclick="switchTab('recordings')">Recordings</button>
            </div>
        </div>
    </header>

    <div class="main-layout">
        <!-- Control Hub Column -->
        <aside id="hubTab" class="tab-content active" style="flex-direction: column; gap: 1.5rem;">
            <div class="card">
                <div class="card-title">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>
                    <span>Control Hub</span>
                </div>
                <div class="card-subtitle">Manage device timers, settings, and network states</div>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label for="durInput">Recording Duration</label>
                        <input type="number" id="durInput" value="{{ config['duration'] }}" min="1">
                    </div>
                    <div class="form-group">
                        <label for="intInput">Recording Pause (Seconds)</label>
                        <input type="number" id="intInput" value="{{ config['pause'] }}" min="0">
                    </div>
                    <div class="form-group">
                        <label for="phoneInput">Telemetry Alert Phone</label>
                        <input type="text" id="phoneInput" value="{{ config['phone'] }}">
                    </div>
                    <div class="form-group">
                        <label for="smsVal">Telemetry Interval</label>
                        <div class="sms-input-group">
                            <input type="number" id="smsVal" value="{{ config['sms_val'] }}" min="1">
                            <select id="smsUnit">
                                <option value="sec" {% if config['sms_unit'] == 'sec' %}selected{% endif %}>sec</option>
                                <option value="min" {% if config['sms_unit'] == 'min' %}selected{% endif %}>min</option>
                                <option value="hr" {% if config['sms_unit'] == 'hr' %}selected{% endif %}>hr</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="btn-group">
                    <button class="btn-tactile primary" onclick="saveSettings()">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                        Apply Configurations
                    </button>
                    <button id="syncBtn" class="btn-tactile" onclick="syncTime()">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                        Sync Device Clock
                    </button>
                    <button id="smsBtn" class="btn-tactile warning" onclick="testSMS()">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
                        Test Telemetry SMS
                    </button>
                    <button id="shutdownBtn" class="btn-tactile danger" onclick="shutdownServer()">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18.36 6.64a9 9 0 1 1-12.73 0"></path><line x1="12" y1="2" x2="12" y2="12"></line></svg>
                        Sleep Wi-Fi
                    </button>
                </div>
            </div>
        </aside>

        <!-- Recordings Table Column -->
        <main id="recordingsTab" class="tab-content" style="flex-direction: column;">
            <div class="card" style="width: 100%;">
                <div class="card-title">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l12-2v13"></path><circle cx="6" cy="18" r="3"></circle><circle cx="18" cy="16" r="3"></circle></svg>
                    <span>Audio Recordings</span>
                </div>
                <div class="card-subtitle">Browse, download, or delete recorded data files</div>

                <div class="files-control-bar">
                    <div class="search-container">
                        <svg class="search-icon" xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" x2="16.65" y1="21" y2="16.65"/></svg>
                        <input type="text" id="searchInput" placeholder="Search recordings..." oninput="filterFiles()">
                    </div>
                    
                    <div class="bulk-actions-group">
                        <label class="checkbox-container">
                            <input type="checkbox" id="selectAll">
                            <div class="custom-checkbox"></div>
                            <span>Select All</span>
                        </label>
                        <button id="bulkDlBtn" class="btn-tactile" onclick="downloadSelected()" style="padding: 0.45rem 1.0rem; font-size: 0.8rem;">
                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>
                            Bulk Download
                        </button>
                        <button class="btn-tactile danger" onclick="deleteSelected()" style="padding: 0.45rem 1.0rem; font-size: 0.8rem;">
                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
                            Bulk Delete
                        </button>
                    </div>
                </div>

                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th style="width: 50px;">Select</th>
                                <th>Filename</th>
                                <th style="width: 130px;">Size</th>
                                <th style="width: 140px;">Status</th>
                                <th style="width: 130px; text-align: center;">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="fileTable">
                            {% for f in files %}
                            <tr class="file-row" id="row_{{ f.name }}" data-filename="{{ f.name }}">
                                <td>
                                    <label class="checkbox-container" style="display: inline-flex; justify-content: center; width: 100%;">
                                        <input type="checkbox" class="file-chk" value="{{ f.name }}">
                                        <div class="custom-checkbox"></div>
                                    </label>
                                </td>
                                <td class="filename">{{ f.name }}</td>
                                <td>{{ f.size_kb }} KB</td>
                                <td id="status_{{ f.name }}">
                                    <span class="badge badge-new">New</span>
                                </td>
                                <td style="text-align: center;">
                                    <div class="actions-cell" style="justify-content: center;">
                                        <a href="/download?file={{ f.name }}" class="btn-icon primary" target="_blank" onclick="markDownloaded('{{ f.name }}')">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>
                                        </a>
                                        <button class="btn-icon danger" onclick="deleteSingle('{{ f.name }}')">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            {% else %}
                            <tr>
                                <td colspan="5">
                                    <div class="empty-state">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5V15c0-1.7 1.3-3 3-3h10c1.7 0 3 1.3 3 3v4.5c0 .8-.7 1.5-1.5 1.5H5.5c-.8 0-1.5-.7-1.5-1.5Z"/><path d="M6 8c0-1.7 1.3-3 3-3h6c1.7 0 3 1.3 3 3v4H6V8Z"/><circle cx="9" cy="18" r="1"/><circle cx="15" cy="18" r="1"/></svg>
                                        <p style="font-weight: 600; margin-bottom: 4px;">No Audio Recording Data Found</p>
                                        <p style="font-size: 0.8rem; color: hsl(var(--muted-foreground));">Ensure the monitoring process is active and capturing data.</p>
                                    </div>
                                </td>
                            </tr>
                            {% endfor %}
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <!-- Dynamic Toast Notification -->
    <div id="toast">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
        <span class="toast-text">Success!</span>
    </div>

    <!-- Progress Modal -->
    <div class="modal" id="progressModal">
        <div class="modal-content">
            <div class="modal-title" id="modalTitle">Downloading Queue</div>
            <div class="progress-container">
                <div class="progress-bar" id="progressBar"></div>
            </div>
            <div class="progress-text" id="modalText">0% Completed</div>
        </div>
    </div>

    <script>
        // Pill Tabs Switcher Logic
        function switchTab(tab) {
            document.querySelectorAll('.mobile-tab-btn').forEach(btn => btn.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
            
            if (tab === 'hub') {
                document.getElementById('hubBtn').classList.add('active');
                document.getElementById('hubTab').classList.add('active');
            } else {
                document.getElementById('recordingsBtn').classList.add('active');
                document.getElementById('recordingsTab').classList.add('active');
            }
        }

        // Live file filtering search implementation
        function filterFiles() {
            const q = document.getElementById('searchInput').value.toLowerCase();
            const rows = document.querySelectorAll('.file-row');
            rows.forEach(row => {
                const fn = row.getAttribute('data-filename');
                if (fn) {
                    if (fn.toLowerCase().includes(q)) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                }
            });
        }

        async function showToast(message) {
            const toast = document.getElementById('toast');
            toast.querySelector('.toast-text').innerText = message;
            toast.classList.add('show');
            setTimeout(() => {
                toast.classList.remove('show');
            }, 3000);
        }

        function showModal(title, text) {
            const modal = document.getElementById('progressModal');
            document.getElementById('modalTitle').innerText = title;
            document.getElementById('modalText').innerText = text;
            document.getElementById('progressBar').style.width = '0%';
            modal.classList.add('show');
        }

        function updateModal(progressPct, text) {
            document.getElementById('progressBar').style.width = progressPct + '%';
            document.getElementById('modalText').innerText = text;
        }

        function hideModal() {
            document.getElementById('progressModal').classList.remove('show');
        }

        async function shutdownServer() {
            if (!confirm('Are you sure you want to put Wi-Fi to sleep? This turns off the web server to conserve battery. You will need to write "Wake" via Bluetooth to turn it back on.')) return;
            try {
                const btn = document.getElementById('shutdownBtn');
                btn.disabled = true;
                btn.innerText = 'Powering down...';
                await fetch('/shutdown');
                document.body.innerHTML = `
                    <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 100vh; text-align: center; padding: 2rem;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#7c66e4" stroke-width="1.5" style="margin-bottom: 24px;"><path d="M18.36 6.64a9 9 0 1 1-12.73 0"/><line x1="12" x2="12" y1="2" y2="12"/></svg>
                        <h1 style="font-family: 'Instrument Serif', Georgia, serif; font-size: 2.25rem; font-style: italic; font-weight: 400; margin-bottom: 12px; color: #fff;">Wi-Fi Sleep Mode Activated</h1>
                        <p style="color: hsl(var(--muted-foreground)); max-width: 500px; font-size: 1rem; line-height: 1.6; font-family: 'Inter', sans-serif;">The web server has been safely shut down. The device is now in autonomous monitoring mode. To wake the server again, reconnect via Bluetooth and send the command "Wake".</p>
                    </div>
                `;
            } catch (e) {
                alert('Shutdown triggered.');
            }
        }

        async function syncTime() {
            const btn = document.getElementById('syncBtn');
            const oldText = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = 'Syncing...';
            
            const now = new Date();
            const url = `/synctime?y=${now.getFullYear()}&m=${now.getMonth()+1}&d=${now.getDate()}&h=${now.getHours()}&min=${now.getMinutes()}&s=${now.getSeconds()}`;
            
            try {
                const res = await fetch(url);
                if (res.ok) {
                    btn.innerHTML = 'Synced!';
                    showToast('System clock synchronized successfully');
                } else {
                    btn.innerHTML = 'Failed';
                    alert('Time sync failed.');
                }
            } catch (e) {
                btn.innerHTML = 'Error';
                alert('Network error.');
            }
            setTimeout(() => {
                btn.disabled = false;
                btn.innerHTML = oldText;
            }, 2000);
        }

        async function testSMS() {
            const btn = document.getElementById('smsBtn');
            const oldText = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = 'Sending...';
            
            try {
                const res = await fetch('/sms');
                if (res.ok) {
                    btn.innerHTML = 'SMS Sent!';
                    showToast('Diagnostic SMS sent successfully');
                } else {
                    btn.innerHTML = 'Failed';
                    alert('SMS failed to send. Check modem connection and phone settings.');
                }
            } catch (e) {
                btn.innerHTML = 'Error';
                alert('Network error.');
            }
            setTimeout(() => {
                btn.disabled = false;
                btn.innerHTML = oldText;
            }, 2000);
        }

        async function saveSettings() {
            const dur = document.getElementById('durInput').value;
            const intv = document.getElementById('intInput').value;
            const phone = encodeURIComponent(document.getElementById('phoneInput').value);
            const smsVal = document.getElementById('smsVal').value;
            const smsUnit = document.getElementById('smsUnit').value;
            
            if (dur <= 0 || intv < 0 || smsVal <= 0) {
                return alert('Values must be positive numbers');
            }
            
            try {
                const res = await fetch(`/settings?dur=${dur}&intv=${intv}&phone=${phone}&smsVal=${smsVal}&smsUnit=${smsUnit}`);
                if (res.ok) {
                    showToast('Settings saved successfully');
                } else {
                    alert('Failed to save settings.');
                }
            } catch (e) {
                alert('Error saving settings.');
            }
        }

        function updateStatus(fn, isDl) {
            const stat = document.getElementById('status_' + fn);
            const row = document.getElementById('row_' + fn);
            if (stat && row) {
                if (isDl) {
                    stat.innerHTML = '<span class="badge badge-downloaded">Downloaded</span>';
                    row.classList.add('dimmed');
                } else {
                    stat.innerHTML = '<span class="badge badge-new">New</span>';
                    row.classList.remove('dimmed');
                }
            }
        }

        function markDownloaded(fn) {
            localStorage.setItem('dl_' + fn, 'true');
            updateStatus(fn, true);
        }

        window.onload = () => {
            document.querySelectorAll('.file-row').forEach(row => {
                const fn = row.getAttribute('data-filename');
                updateStatus(fn, localStorage.getItem('dl_' + fn) === 'true');
            });
        };

        document.getElementById('selectAll').addEventListener('change', function(e) {
            document.querySelectorAll('.file-chk').forEach(c => c.checked = e.target.checked);
        });

        // Client-side ZIP generation (uncompressed/store method)
        function createZip(files) {
            const crcTable = [];
            for (let n = 0; n < 256; n++) {
                let c = n;
                for (let k = 0; k < 8; k++) {
                    c = ((c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1));
                }
                crcTable[n] = c;
            }

            function crc32(buf) {
                const u8 = new Uint8Array(buf);
                let crc = 0 ^ (-1);
                for (let i = 0; i < u8.length; i++) {
                    crc = (crc >>> 8) ^ crcTable[(crc ^ u8[i]) & 0xFF];
                }
                return (crc ^ (-1)) >>> 0;
            }

            let parts = [];
            let offsets = [];
            let currentOffset = 0;

            // 1. Local File Headers
            files.forEach((f) => {
                const nameBytes = new TextEncoder().encode(f.name.replace('/', ''));
                const fileData = new Uint8Array(f.buffer);
                const fileCrc = crc32(f.buffer);
                const fileLen = fileData.length;

                const lfh = new Uint8Array(30 + nameBytes.length);
                
                // Signature: PK\3\4
                lfh[0] = 0x50; lfh[1] = 0x4b; lfh[2] = 0x03; lfh[3] = 0x04;
                // Version needed to extract: 10
                lfh[4] = 10; lfh[5] = 0;
                // General purpose bit flag: 0
                lfh[6] = 0; lfh[7] = 0;
                // Compression method: 0 (Store)
                lfh[8] = 0; lfh[9] = 0;
                // Last mod file time/date: 0
                lfh[10] = 0; lfh[11] = 0;
                lfh[12] = 0; lfh[13] = 0;
                
                // CRC-32
                lfh[14] = fileCrc & 0xff;
                lfh[15] = (fileCrc >> 8) & 0xff;
                lfh[16] = (fileCrc >> 16) & 0xff;
                lfh[17] = (fileCrc >> 24) & 0xff;

                // Compressed size
                lfh[18] = fileLen & 0xff;
                lfh[19] = (fileLen >> 8) & 0xff;
                lfh[20] = (fileLen >> 16) & 0xff;
                lfh[21] = (fileLen >> 24) & 0xff;

                // Uncompressed size
                lfh[22] = fileLen & 0xff;
                lfh[23] = (fileLen >> 8) & 0xff;
                lfh[24] = (fileLen >> 16) & 0xff;
                lfh[25] = (fileLen >> 24) & 0xff;

                // Filename length
                lfh[26] = nameBytes.length & 0xff;
                lfh[27] = (nameBytes.length >> 8) & 0xff;

                // Extra field length: 0
                lfh[28] = 0; lfh[29] = 0;

                // Filename
                lfh.set(nameBytes, 30);

                offsets.push(currentOffset);
                parts.push(lfh);
                parts.push(fileData);

                currentOffset += lfh.length + fileData.length;
            });

            // 2. Central Directory
            let centralDirectoryOffset = currentOffset;
            let centralDirectorySize = 0;

            files.forEach((f, idx) => {
                const nameBytes = new TextEncoder().encode(f.name.replace('/', ''));
                const fileCrc = crc32(f.buffer);
                const fileLen = f.buffer.byteLength;
                const offset = offsets[idx];

                const cdh = new Uint8Array(46 + nameBytes.length);

                // Signature: PK\1\2
                cdh[0] = 0x50; cdh[1] = 0x4b; cdh[2] = 0x01; cdh[3] = 0x02;
                // Version made by: 20
                cdh[4] = 20; cdh[5] = 0;
                // Version needed to extract: 10
                cdh[6] = 10; cdh[7] = 0;
                // General purpose bit flag: 0
                cdh[8] = 0; cdh[9] = 0;
                // Compression method: 0
                cdh[10] = 0; cdh[11] = 0;
                // Last mod file time/date: 0
                cdh[12] = 0; cdh[13] = 0;
                cdh[14] = 0; cdh[15] = 0;

                // CRC-32
                cdh[16] = fileCrc & 0xff;
                cdh[17] = (fileCrc >> 8) & 0xff;
                cdh[18] = (fileCrc >> 16) & 0xff;
                cdh[19] = (fileCrc >> 24) & 0xff;

                // Compressed size
                cdh[20] = fileLen & 0xff;
                cdh[21] = (fileLen >> 8) & 0xff;
                cdh[22] = (fileLen >> 16) & 0xff;
                cdh[23] = (fileLen >> 24) & 0xff;

                // Uncompressed size
                cdh[24] = fileLen & 0xff;
                cdh[25] = (fileLen >> 8) & 0xff;
                cdh[26] = (fileLen >> 16) & 0xff;
                cdh[27] = (fileLen >> 24) & 0xff;

                // Filename length
                cdh[28] = nameBytes.length & 0xff;
                cdh[29] = (nameBytes.length >> 8) & 0xff;

                // Extra field length: 0
                cdh[30] = 0; cdh[31] = 0;
                // File comment length: 0
                cdh[32] = 0; cdh[33] = 0;
                // Disk number start: 0
                cdh[34] = 0; cdh[35] = 0;
                // Internal file attributes: 0
                cdh[36] = 0; cdh[37] = 0;
                // External file attributes: 0
                cdh[38] = 0; cdh[39] = 0; cdh[40] = 0; cdh[41] = 0;

                // Local header offset
                cdh[42] = offset & 0xff;
                cdh[43] = (offset >> 8) & 0xff;
                cdh[44] = (offset >> 16) & 0xff;
                cdh[45] = (offset >> 24) & 0xff;

                // Filename
                cdh.set(nameBytes, 46);

                parts.push(cdh);
                centralDirectorySize += cdh.length;
            });

            // 3. End of Central Directory
            const eocd = new Uint8Array(22);

            // Signature: PK\5\6
            eocd[0] = 0x50; eocd[1] = 0x4b; eocd[2] = 0x05; eocd[3] = 0x06;
            // Disk number: 0
            eocd[4] = 0; eocd[5] = 0;
            // Start disk: 0
            eocd[6] = 0; eocd[7] = 0;
            // Entries on disk:
            eocd[8] = files.length & 0xff;
            eocd[9] = (files.length >> 8) & 0xff;
            // Total entries:
            eocd[10] = files.length & 0xff;
            eocd[11] = (files.length >> 8) & 0xff;
            // Central directory size:
            eocd[12] = centralDirectorySize & 0xff;
            eocd[13] = (centralDirectorySize >> 8) & 0xff;
            eocd[14] = (centralDirectorySize >> 16) & 0xff;
            eocd[15] = (centralDirectorySize >> 24) & 0xff;
            // Central directory offset:
            eocd[16] = centralDirectoryOffset & 0xff;
            eocd[17] = (centralDirectoryOffset >> 8) & 0xff;
            eocd[18] = (centralDirectoryOffset >> 16) & 0xff;
            eocd[19] = (centralDirectoryOffset >> 24) & 0xff;
            // Comment length: 0
            eocd[20] = 0; eocd[21] = 0;

            parts.push(eocd);

            return new Blob(parts, { type: 'application/zip' });
        }

        async function downloadSelected() {
            const checks = document.querySelectorAll('.file-chk:checked');
            if (checks.length === 0) return alert('No files selected!');
            
            showModal('Preparing Downloads', 'Starting download queue...');
            let zipFiles = [];
            
            for (let i = 0; i < checks.length; i++) {
                let fn = checks[i].value;
                let progress = Math.round((i / checks.length) * 100);
                updateModal(progress, `Fetching file ${i + 1} of ${checks.length}: ${fn}`);
                
                try {
                    let res = await fetch('/download?file=' + fn);
                    if (res.ok) {
                        let buf = await res.arrayBuffer();
                        zipFiles.push({ name: fn, buffer: buf });
                        markDownloaded(fn);
                    }
                } catch (e) {
                    console.error('Failed to fetch', fn, e);
                }
                await new Promise(r => setTimeout(r, 50));
            }
            
            updateModal(95, 'Zipping files into ZIP archive...');
            await new Promise(r => setTimeout(r, 100));
            
            try {
                let zipBlob = createZip(zipFiles);
                let url = window.URL.createObjectURL(zipBlob);
                let a = document.createElement('a');
                a.href = url;
                
                let d = new Date();
                let ts = d.getFullYear() + 
                         ('0' + (d.getMonth() + 1)).slice(-2) + 
                         ('0' + d.getDate()).slice(-2) + '_' + 
                         ('0' + d.getHours()).slice(-2) + 
                         ('0' + d.getMinutes()).slice(-2);
                
                a.download = 'Rainforest_Data_' + ts + '.zip';
                document.body.appendChild(a);
                a.click();
                a.remove();
                window.URL.revokeObjectURL(url);
                showToast('Downloaded ' + zipFiles.length + ' files successfully');
            } catch (err) {
                alert('Error creating archive: ' + err.message);
            } finally {
                hideModal();
            }
        }

        async function deleteSelected() {
            const checks = document.querySelectorAll('.file-chk:checked');
            if (checks.length === 0) return alert('No files selected!');
            if (!confirm(`Are you sure you want to permanently delete these ${checks.length} files?`)) return;
            
            showModal('Deleting Files', 'Deleting queue...');
            for (let i = 0; i < checks.length; i++) {
                let fn = checks[i].value;
                let progress = Math.round((i / checks.length) * 100);
                updateModal(progress, `Deleting ${fn}...`);
                
                try {
                    await fetch('/delete?file=' + fn);
                    localStorage.removeItem('dl_' + fn);
                } catch (e) {
                    console.error('Failed to delete', fn, e);
                }
            }
            hideModal();
            window.location.reload();
        }

        async function deleteSingle(fn) {
            if (!confirm('Are you sure you want to delete ' + fn + '?')) return;
            document.getElementById('row_' + fn).style.opacity = '0.4';
            try {
                const res = await fetch('/delete?file=' + fn);
                if (res.ok) {
                    localStorage.removeItem('dl_' + fn);
                    window.location.reload();
                } else {
                    alert('Failed to delete ' + fn);
                    document.getElementById('row_' + fn).style.opacity = '1';
                }
            } catch (e) {
                alert('Network error.');
                document.getElementById('row_' + fn).style.opacity = '1';
            }
        }
    </script>
</body>
</html>"""

@app.route("/")
def index():
    files_list = []
    try:
        if os.path.exists(server_state.output_dir):
            for f in os.listdir(server_state.output_dir):
                path = os.path.join(server_state.output_dir, f)
                if os.path.isfile(path) and f.endswith(".wav"):
                    size_kb = os.path.getsize(path) / 1024.0
                    files_list.append({
                        "name": f,
                        "size_kb": round(size_kb, 1)
                    })
    except Exception as e:
        print("[ERROR] Scanning recordings directory failed:", e)
        
    # Sort descending by filename (newer recordings first)
    files_list.sort(key=lambda x: x["name"], reverse=True)
    
    bat_pct = server_state.get_battery_percentage()
    sd_pct = server_state.get_sd_percentage()
    
    return render_template_string(
        DASHBOARD_HTML,
        files=files_list,
        config=server_state.config,
        bat_pct=bat_pct,
        sd_pct=round(sd_pct, 1)
    )

@app.route("/download")
def download_file():
    filename = request.args.get("file")
    if not filename:
        return "Missing file name", 400
        
    filename = os.path.basename(filename)
    filepath = os.path.join(server_state.output_dir, filename)
    
    if os.path.exists(filepath) and os.path.isfile(filepath):
        return send_from_directory(server_state.output_dir, filename, as_attachment=True)
    return "File Not Found", 404

@app.route("/delete")
def delete_file():
    filename = request.args.get("file")
    if not filename:
        return "Missing file name", 400
        
    filename = os.path.basename(filename)
    filepath = os.path.join(server_state.output_dir, filename)
    
    if os.path.exists(filepath) and os.path.isfile(filepath):
        try:
            os.remove(filepath)
            return "Deleted OK"
        except Exception as e:
            print("[FILE ERROR] Failed to delete file:", e)
            return "Delete failed", 500
    return "File Not Found", 404

@app.route("/settings")
def update_settings():
    try:
        dur = request.args.get("dur", type=int)
        intv = request.args.get("intv", type=int)
        phone = request.args.get("phone")
        sms_val = request.args.get("smsVal", type=int)
        sms_unit = request.args.get("smsUnit")
        
        config = server_state.config.copy()
        
        if dur is not None and dur > 0:
            config["duration"] = dur
        if intv is not None and intv >= 0:
            config["pause"] = intv
        if phone:
            config["phone"] = phone.strip()
        if sms_val is not None and sms_val > 0:
            config["sms_val"] = sms_val
        if sms_unit in ["sec", "min", "hr"]:
            config["sms_unit"] = sms_unit
            
        server_state.save_config(config)
        return "Settings Saved OK"
    except Exception as e:
        print("[SETTINGS ERROR] Failed to update settings:", e)
        return "Error updating settings", 500

@app.route("/sms")
def test_sms():
    sd_pct = server_state.get_sd_percentage()
    bat_pct = server_state.get_battery_percentage()
    message = f"Manual Alert:\nSD Card: {sd_pct:.1f}%\nBattery: {bat_pct}%"
    success = server_state.send_sms(message)
    if success:
        return "SMS Diagnostic Triggered"
    else:
        return "SMS Failed", 500

@app.route("/synctime")
def sync_time():
    y = request.args.get("y")
    m = request.args.get("m")
    d = request.args.get("d")
    h = request.args.get("h")
    minute = request.args.get("min")
    s = request.args.get("s")
    
    if y and m and d and h and minute and s:
        # Date string formatting: "YYYY-MM-DD HH:MM:SS"
        date_str = f"{y}-{int(m):02d}-{int(d):02d} {int(h):02d}:{int(minute):02d}:{int(s):02d}"
        try:
            subprocess.run(["sudo", "date", "-s", date_str], check=True)
            print(f"[TIME] System clock set to: {date_str}")
            return "Time Synced OK"
        except Exception as e:
            print("[TIME ERROR] Failed to synchronize clock:", e)
            return "Failed to sync time", 500
    return "Missing arguments", 400

@app.route("/shutdown")
def shutdown_wifi():
    # Execute a delayed shutdown of Wi-Fi in the background so that the response returns cleanly first
    def delayed_shutdown():
        time.sleep(2)
        server_state.sleep_wifi()
        
    threading.Thread(target=delayed_shutdown, daemon=True).start()
    return "Shutting Down"

# -----------------------------------------------------------------------------
# AUTONOMOUS TELEMETRY SMS SCHEDULER
# -----------------------------------------------------------------------------
def sms_scheduler_thread(state):
    print("[SMS] Scheduler background daemon initialized")
    while True:
        sms_val = state.config.get("sms_val", 1)
        sms_unit = state.config.get("sms_unit", "hr")
        
        multiplier = 1
        if sms_unit == "sec":
            multiplier = 1
        elif sms_unit == "min":
            multiplier = 60
        elif sms_unit == "hr":
            multiplier = 3600
            
        sms_interval = sms_val * multiplier
        current_time = time.time()
        
        # Only send SMS if the Web server / Wi-Fi is sleeping to match ESP32 logic
        if not state.is_wifi_active:
            if current_time - state.last_sms_time >= sms_interval:
                sd_pct = state.get_sd_percentage()
                bat_pct = state.get_battery_percentage()
                msg = f"Rainforest Monitor Alert:\nSD Card Used: {sd_pct:.1f}%\nBattery Level: {bat_pct}%\nStatus: Active."
                state.send_sms(msg)
                state.last_sms_time = current_time
                
        time.sleep(5)

# -----------------------------------------------------------------------------
# BLE SERVER EXECUTABLE DAEMON
# -----------------------------------------------------------------------------
def run_ble_server(state):
    if not DBUS_SUPPORTED:
        print("[BLE] D-Bus not supported on this platform. Running in mock BLE mode.")
        return
        
    try:
        dbus.mainloop.glib.DBusGMainLoop(set_as_default=True)
        bus = dbus.SystemBus()
        
        adapter_path = find_adapter(bus)
        if not adapter_path:
            print("[BLE ERROR] No eligible Bluetooth adapter found with GATT support.")
            return
            
        print(f"[BLE] Exposing BLE server on adapter: {adapter_path}")
        
        service_uuid = "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
        ad = Advertisement(bus, 0, service_uuid)
        
        app = Application(bus)
        service = Service(bus, 0, service_uuid, True)
        app.add_service(service)
        
        char_uuid = "beb5483e-36e1-4688-b7f5-ea07361b26a8"
        char = MuleControlCharacteristic(bus, 0, char_uuid, service, state)
        service.add_characteristic(char)
        
        register_ble_ad(bus, adapter_path, ad)
        register_ble_app(bus, adapter_path, app)
        
        mainloop = GLib.MainLoop()
        print("[BLE] BLE Server running and advertising as 'Forest_Ear_BLE'")
        mainloop.run()
    except Exception as e:
        print("[BLE ERROR] BLE daemon failed to register objects:", e)

# -----------------------------------------------------------------------------
# ENTRYPOINT CONFIGURATION
# -----------------------------------------------------------------------------
if __name__ == "__main__":
    # Start the BLE advertising and GATT server daemon in a background thread
    ble_thread = threading.Thread(target=run_ble_server, args=(server_state,), daemon=True)
    ble_thread.start()
    
    # Start the autonomous telemetry SMS scheduler in a background thread
    sms_thread = threading.Thread(target=sms_scheduler_thread, args=(server_state,), daemon=True)
    sms_thread.start()
    
    # Start with Wi-Fi disabled by default for telemetry and battery saving
    # The user wakes up the system via BLE
    # Set to False initially. If running inside dev environment, we can choose to unblock it first.
    server_state.sleep_wifi()
    
    print("[INFO] Rainforest Data Mule System initialized.")
    print("[INFO] BLE interface active continuously.")
    print("[INFO] Web UI server will be activated upon receiving 'wake' command.")
    
    # Keep the main thread alive (since Flask is now started dynamically upon BLE wake)
    try:
        while True:
            time.sleep(10)
    except KeyboardInterrupt:
        print("[INFO] Stopping Rainforest Data Mule System...")
