import subprocess
import datetime
import os
import time

# -------------------------------------------------
# CONFIGURATION
# -------------------------------------------------
OUTPUT_DIR = "/media/rpi/soundscape"

RECORD_INTERVAL = 1 * 10       # 5 minutes = 300 seconds
AUDIO_DEVICE = "plughw:3,0"

# -------------------------------------------------
# AUDIO SETTINGS
# -------------------------------------------------
SAMPLE_RATE = 32000
CHANNELS = 1
BIT_DEPTH = 16

# -------------------------------------------------
# GAIN CONTROL
# -------------------------------------------------
# 0 dB  = Original microphone level
# 5 dB  = Slight amplification
# 10 dB = Moderate amplification
# 15 dB = High amplification
# 20 dB = Very high amplification
#
# Recommended starting value: 0 or 5 dB
GAIN_DB = 20


# -------------------------------------------------
# AUDIO DEVICE CHECK
# -------------------------------------------------
def wait_for_audio_device(timeout=60):

    print("[INFO] Waiting for USB microphone...")

    for _ in range(timeout):

        try:
            result = subprocess.run(
                ["arecord", "-l"],
                capture_output=True,
                text=True
            )

            if "card 3" in result.stdout:
                print("[OK] Audio device detected")
                return True

        except Exception as e:
            print("[WARNING] Audio device check failed:", e)

        time.sleep(1)

    print("[ERROR] Audio device not detected")
    return False


# -------------------------------------------------
# RECORD AUDIO
# -------------------------------------------------
def record_audio():

    timestamp = datetime.datetime.now().strftime(
        "%Y%m%d_%H%M%S"
    )

    wav_file = os.path.join(
        OUTPUT_DIR,
        f"{timestamp}.wav"
    )

    # -------------------------------------------------
    # RECORDING COMMAND
    # -------------------------------------------------
    # Only gain is applied.
    # No normalization.
    # No compression.
    # No filtering.
    # -------------------------------------------------

    record_cmd = [
        "sox",
        "-t",
        "alsa",
        "-D",
        AUDIO_DEVICE,

        "-c",
        str(CHANNELS),

        "-b",
        str(BIT_DEPTH),

        "-r",
        str(SAMPLE_RATE),

        wav_file,

        "trim",
        "0",
        str(RECORD_INTERVAL),

        "gain",
        str(GAIN_DB)
    ]

    try:

        print(
            f"[RECORDING] {os.path.basename(wav_file)}"
        )

        print(
            f"[INFO] Gain: {GAIN_DB} dB"
        )

        subprocess.run(
            record_cmd,
            check=True
        )

        print(
            f"[SAVED] {os.path.basename(wav_file)}"
        )

        return True

    except subprocess.CalledProcessError as e:

        print(
            "[ERROR] Recording failed:",
            e
        )

        return False


# -------------------------------------------------
# MAIN
# -------------------------------------------------
if __name__ == "__main__":

    os.makedirs(
        OUTPUT_DIR,
        exist_ok=True
    )

    # Check USB microphone
    if not wait_for_audio_device():
        raise SystemExit(1)

    print(
        "\n[INFO] Continuous 5-minute audio recording started"
    )

    print(
        f"[INFO] Audio device : {AUDIO_DEVICE}"
    )

    print(
        f"[INFO] Sample rate  : {SAMPLE_RATE} Hz"
    )

    print(
        f"[INFO] Bit depth    : {BIT_DEPTH}-bit"
    )

    print(
        f"[INFO] Channels     : {CHANNELS}"
    )

    print(
        f"[INFO] Gain         : {GAIN_DB} dB"
    )

    print(
        f"[INFO] Output       : {OUTPUT_DIR}"
    )

    try:

        while True:

            record_audio()

            # No sleep here.
            # The next recording starts immediately
            # after the previous recording finishes.

    except KeyboardInterrupt:

        print(
            "\n[INFO] Recording stopped by user"
        )


